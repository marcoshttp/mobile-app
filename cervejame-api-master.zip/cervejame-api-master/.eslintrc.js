module.exports = {
    "env": {
        "jest": true
    },
    "extends": "standard",
    "plugins": ["jest"]
}
