export const paymentConstant = {
  CASH: {
    code: 1,
    message: 'Dinheiro'
  },
  CREDIT_CARD: {
    code: 2,
    message: 'Cartão de Crédito'
  },
  APP_CREDIT_CARD: {
    code: 3,
    message: 'Via Cerveja-me'
  },
  BEER_COIN: {
    code: 4,
    message: 'Beer-coin'
  }
}
