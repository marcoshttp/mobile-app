export const profileConstant = {
  FORM: {
    code: 1,
    message: 'Formulário'
  },
  FACEBOOK: {
    code: 2,
    message: 'Facebook'
  },
  SELLER: {
    code: 3,
    message: 'Vendedor'
  }
}
