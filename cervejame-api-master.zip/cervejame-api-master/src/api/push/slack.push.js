import request from 'request'

const API_MQ_URL = process.env.API_MQ_URL || 'http://localhost:8081'
const options = {
  url: API_MQ_URL + '/slack/send',
  headers: {
    'Content-Type': 'application/json'
  }
}
export function slack (t) {
  options.json = true
  options.body = JSON.stringify(t)
  request.post(options, (e, res, body) => {
    if (e) console.log(e)
    if (res) console.log(JSON.stringify(res))
    if (body) console.log(body)
  })
}