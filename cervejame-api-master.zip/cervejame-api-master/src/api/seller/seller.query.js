export const GET_SELLER_FROM_PROFILE = 'select * from seller where id_profile = $1'
