# Cerveja.me backend

[ ![Codeship Status for guardez/cervejame-backend](https://app.codeship.com/projects/da1652d0-992e-0134-dcb4-1674c9cbc38f/status?branch=master)](https://app.codeship.com/projects/187633)

a [Sails](http://sailsjs.org) application


###schedule jobs
https://dzone.com/articles/scheduling-jobs-on-a-sailsjs-application

###push
https://www.npmjs.com/package/fcm-node

### Telegram
https://github.com/yagop/node-telegram-bot-api

#oneSingal notification
simple wraper

https://www.npmjs.com/package/onesignal-plus
