/**
 * ApperrorController
 *
 * @description :: Server-side logic for managing apperrors
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

 module.exports = {

 };

