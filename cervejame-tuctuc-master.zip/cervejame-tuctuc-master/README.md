# README #


### developing ###

```
git clone git@bitbucket.org:guardez/cervejame-tuctuc.git
npm -i
ionic serve
```

